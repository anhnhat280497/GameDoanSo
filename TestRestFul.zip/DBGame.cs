namespace TestRestFul
{
    partial class DBGameDataContext
    {
       
    }
}